<?php
 
 $conn = mysqli_connect("localhost","db-user","password","db-name");

 // $sql = "use id2613481_sensora";
?>